package com.skylyrics;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LyricsPlayer {
    record Line(String text, long ms) {}

    public static class Active {
        public String text;
        public long spawn;
        public boolean around;
        public Vec3d fixed;
        public double ang, h;

        public Vec3d pos(PlayerEntity p, float td, long now) {
            if (!around) return fixed;
            double a = ang + (now - spawn) * 0.0003;
            Vec3d b = p.getLerpedPos(td);
            return b.add(Math.cos(a) * 4, h, Math.sin(a) * 4);
        }
    }

    private static final Pattern LRC = Pattern.compile("^\\[(\\d+):(\\d+(?:\\.\\d+)?)](.*)$");
    private final List<Line> lines = new ArrayList<>();
    public final List<Active> active = new ArrayList<>();
    private final Random rng = new Random();
    private boolean playing;
    private long start;
    private int next;

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("skylyrics");
    }

    public int load() {
        lines.clear();
        try {
            Files.createDirectories(dir());
            Path f = dir().resolve("lyrics.txt");
            if (!Files.exists(f)) {
                Files.writeString(f, "Put your lyrics in this file\nOne line per line\n"
                    + "Or use timestamps like [00:12.50]your line\n");
            }
            for (String raw : Files.readAllLines(f)) {
                String s = raw.trim();
                if (s.isEmpty()) continue;
                Matcher m = LRC.matcher(s);
                if (m.matches()) {
                    long ms = (long) ((Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2))) * 1000);
                    String t = m.group(3).trim();
                    if (!t.isEmpty()) lines.add(new Line(t, ms));
                } else if (!s.startsWith("[")) {
                    lines.add(new Line(s, -1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines.size();
    }

    public void start() {
        active.clear();
        next = 0;
        start = System.currentTimeMillis();
        playing = !lines.isEmpty();
    }

    public void stop() {
        playing = false;
        active.clear();
    }

    private long timeOf(int i) {
        Line l = lines.get(i);
        return l.ms() >= 0 ? l.ms() : (long) (i * SkyLyricsClient.CFG.interval * 1000);
    }

    public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) { active.clear(); return; }
        long now = System.currentTimeMillis();
        if (playing) {
            long el = now - start;
            while (next < lines.size() && timeOf(next) <= el) spawn(p, lines.get(next).text(), next, now);
        }
        long life = (long) (SkyLyricsClient.CFG.lifetime * 1000);
        active.removeIf(a -> now - a.spawn > life);
    }

    private void spawn(ClientPlayerEntity p, String text, int i, long now) {
        next = i + 1;
        Config c = SkyLyricsClient.CFG;
        Active a = new Active();
        a.text = text;
        a.spawn = now;
        if (c.mode.equals("around")) {
            a.around = true;
            a.ang = i * 0.9;
            a.h = 0.5 + rng.nextDouble() * 2.5;
        } else {
            double yaw = Math.toRadians(p.getYaw() + (rng.nextDouble() - 0.5) * 100);
            double el = Math.toRadians(20 + rng.nextDouble() * 35);
            Vec3d dir = new Vec3d(-Math.sin(yaw) * Math.cos(el), Math.sin(el), Math.cos(yaw) * Math.cos(el));
            a.fixed = p.getEyePos().add(dir.multiply(c.distance));
        }
        active.add(a);
    }
}
