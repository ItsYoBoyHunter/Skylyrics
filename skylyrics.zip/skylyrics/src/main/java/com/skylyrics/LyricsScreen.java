package com.skylyrics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class LyricsScreen extends Screen {
    private static final String[] COLORS = {"FFFFFF", "00FFFF", "FF4FD8", "FFE14D", "7CFF6B", "FF5555"};
    private final List<String> skies = new ArrayList<>();
    private String status = "";

    public LyricsScreen() {
        super(Text.literal("Sky Lyrics"));
        skies.add("vanilla");
        skies.addAll(Config.SKIES.keySet());
    }

    private static class Slider extends SliderWidget {
        private final String label;
        private final float min, max;
        private final Consumer<Float> set;

        Slider(int x, int y, int w, String label, float min, float max, float cur, Consumer<Float> set) {
            super(x, y, w, 20, Text.empty(), (Math.min(max, Math.max(min, cur)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.set = set;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (label == null) return;
            setMessage(Text.literal(label + ": " + String.format("%.1f", min + (max - min) * value)));
        }

        @Override
        protected void applyValue() {
            set.accept((float) (min + (max - min) * value));
        }
    }

    @Override
    protected void init() {
        Config c = SkyLyricsClient.CFG;
        int w = 150;
        int lx = width / 2 - w - 4;
        int rx = width / 2 + 4;
        int y = Math.max(34, height / 2 - 70);
        int step = 24;

        // Left column
        addDrawableChild(ButtonWidget.builder(Text.literal("Mode: " + c.mode), b -> {
            c.mode = c.mode.equals("sky") ? "around" : "sky";
            b.setMessage(Text.literal("Mode: " + c.mode));
        }).dimensions(lx, y, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Sky: " + c.sky), b -> {
            int i = skies.indexOf(c.sky);
            c.sky = skies.get((i + 1) % skies.size());
            b.setMessage(Text.literal("Sky: " + c.sky));
        }).dimensions(lx, y + step, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Text color: #" + c.color), b -> {
            int idx = -1;
            for (int i = 0; i < COLORS.length; i++) if (COLORS[i].equalsIgnoreCase(c.color)) idx = i;
            c.color = COLORS[(idx + 1) % COLORS.length];
            b.setMessage(Text.literal("Text color: #" + c.color));
        }).dimensions(lx, y + step * 2, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Start"), b -> {
            SkyLyricsClient.PLAYER.start();
            close();
        }).dimensions(lx, y + step * 3, 73, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Stop"), b -> {
            SkyLyricsClient.PLAYER.stop();
            status = "Stopped";
        }).dimensions(lx + 77, y + step * 3, 73, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Reload lyrics file"), b ->
            status = "Loaded " + SkyLyricsClient.PLAYER.load() + " lines"
        ).dimensions(lx, y + step * 4, w, 20).build());

        // Right column
        addDrawableChild(new Slider(rx, y, w, "Size", 0.3f, 4f, c.scale, v -> c.scale = v));
        addDrawableChild(new Slider(rx, y + step, w, "Sky distance", 10f, 150f, c.distance, v -> c.distance = v));
        addDrawableChild(new Slider(rx, y + step * 2, w, "Sec per line", 0.5f, 10f, c.interval, v -> c.interval = v));
        addDrawableChild(new Slider(rx, y + step * 3, w, "Line lifetime", 2f, 20f, c.lifetime, v -> c.lifetime = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Paste lyrics from clipboard"), b -> pasteLyrics())
            .dimensions(rx, y + step * 4, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
            .dimensions(width / 2 - 60, y + step * 5 + 6, 120, 20).build());
    }

    private void pasteLyrics() {
        try {
            String clip = MinecraftClient.getInstance().keyboard.getClipboard();
            if (clip == null || clip.isBlank()) {
                status = "Clipboard is empty";
                return;
            }
            Files.createDirectories(LyricsPlayer.dir());
            Files.writeString(LyricsPlayer.dir().resolve("lyrics.txt"), clip);
            status = "Saved! Loaded " + SkyLyricsClient.PLAYER.load() + " lines";
        } catch (Exception e) {
            status = "Could not save lyrics";
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Sky Lyrics", width / 2, Math.max(34, height / 2 - 70) - 18, 0xFFFFFF);
        if (!status.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, height - 24, 0xFFE14D);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        SkyLyricsClient.CFG.save();
    }
}
