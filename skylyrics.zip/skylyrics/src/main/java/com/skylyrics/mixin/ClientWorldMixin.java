package com.skylyrics.mixin;

import com.skylyrics.SkyLyricsClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void skylyrics$sky(Vec3d pos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        Vec3d c = SkyLyricsClient.CFG.skyColor();
        if (c != null) cir.setReturnValue(c);
    }
}
