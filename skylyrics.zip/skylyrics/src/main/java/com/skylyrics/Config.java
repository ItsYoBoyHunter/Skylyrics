package com.skylyrics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class Config {
    public String mode = "sky";        // "sky" or "around"
    public String sky = "vanilla";     // preset name, 6-digit hex, or "vanilla"
    public String color = "FFFFFF";    // lyric text color
    public float scale = 1f;
    public float distance = 60f;       // sky mode distance
    public float interval = 3f;        // seconds between lines when no timestamps
    public float lifetime = 8f;        // seconds each line stays

    public static final Map<String, String> SKIES = new LinkedHashMap<>();
    static {
        SKIES.put("sunset", "FF7A5C");
        SKIES.put("neon", "FF2BD6");
        SKIES.put("galaxy", "2B1055");
        SKIES.put("midnight", "05051A");
        SKIES.put("ocean", "0077B6");
        SKIES.put("blood", "8B0000");
        SKIES.put("mint", "7DF9C2");
        SKIES.put("gold", "FFC83D");
    }

    private static final Gson G = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("skylyrics.json");
    }

    public static Config load() {
        try {
            if (Files.exists(file())) {
                Config c = G.fromJson(Files.readString(file()), Config.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {}
        return new Config();
    }

    public void save() {
        try { Files.writeString(file(), G.toJson(this)); } catch (Exception ignored) {}
    }

    public static int hex(String s, int def) {
        try { return Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF; }
        catch (Exception e) { return def; }
    }

    public Vec3d skyColor() {
        String h = SKIES.get(sky);
        if (h == null && sky.replace("#", "").matches("[0-9a-fA-F]{6}")) h = sky.replace("#", "");
        if (h == null) return null;
        int c = hex(h, 0);
        return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }
}
