package com.skylyrics;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class SkyLyricsClient implements ClientModInitializer {
    public static final Config CFG = Config.load();
    public static final LyricsPlayer PLAYER = new LyricsPlayer();
    public static KeyBinding MENU_KEY;
    public static boolean openMenu;

    private static void say(CommandContext<FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Text.literal(s));
    }

    @Override
    public void onInitializeClient() {
        PLAYER.load();
        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.skylyrics.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.skylyrics"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            PLAYER.tick();
            while (MENU_KEY.wasPressed()) openMenu = true;
            if (openMenu && mc.currentScreen == null) {
                openMenu = false;
                mc.setScreen(new LyricsScreen());
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((d, r) -> d.register(literal("lyrics")
            .then(literal("menu").executes(c -> { openMenu = true; return 1; }))
            .then(literal("start").executes(c -> { PLAYER.start(); say(c, "Lyrics started"); return 1; }))
            .then(literal("stop").executes(c -> { PLAYER.stop(); say(c, "Lyrics stopped"); return 1; }))
            .then(literal("reload").executes(c -> { say(c, "Loaded " + PLAYER.load() + " lines"); return 1; }))
            .then(literal("folder").executes(c -> { say(c, "Put lyrics.txt in: " + LyricsPlayer.dir()); return 1; }))
            .then(literal("mode").then(argument("m", StringArgumentType.word()).executes(c -> {
                String m = StringArgumentType.getString(c, "m");
                if (!m.equals("sky") && !m.equals("around")) { say(c, "Use: sky or around"); return 0; }
                CFG.mode = m; CFG.save(); say(c, "Mode: " + m); return 1;
            })))
            .then(literal("sky").then(argument("s", StringArgumentType.word()).executes(c -> {
                CFG.sky = StringArgumentType.getString(c, "s"); CFG.save();
                say(c, "Sky: " + CFG.sky + " (presets: " + String.join(", ", Config.SKIES.keySet()) + ", vanilla, or a hex like FF00AA)");
                return 1;
            })))
            .then(literal("color").then(argument("h", StringArgumentType.word()).executes(c -> {
                CFG.color = StringArgumentType.getString(c, "h"); CFG.save(); say(c, "Text color: " + CFG.color); return 1;
            })))
            .then(literal("scale").then(argument("v", FloatArgumentType.floatArg(0.1f, 10f)).executes(c -> {
                CFG.scale = FloatArgumentType.getFloat(c, "v"); CFG.save(); say(c, "Scale: " + CFG.scale); return 1;
            })))
            .then(literal("distance").then(argument("v", FloatArgumentType.floatArg(10f, 200f)).executes(c -> {
                CFG.distance = FloatArgumentType.getFloat(c, "v"); CFG.save(); say(c, "Sky distance: " + CFG.distance); return 1;
            })))
            .then(literal("interval").then(argument("v", FloatArgumentType.floatArg(0.5f, 30f)).executes(c -> {
                CFG.interval = FloatArgumentType.getFloat(c, "v"); CFG.save(); say(c, "Seconds per line: " + CFG.interval); return 1;
            })))
        ));

        WorldRenderEvents.LAST.register(ctx -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || PLAYER.active.isEmpty()) return;
            MatrixStack m = ctx.matrixStack();
            Vec3d cam = ctx.camera().getPos();
            VertexConsumerProvider.Immediate vc = mc.getBufferBuilders().getEntityVertexConsumers();
            TextRenderer font = mc.textRenderer;
            long now = System.currentTimeMillis();
            long life = (long) (CFG.lifetime * 1000);
            int rgb = Config.hex(CFG.color, 0xFFFFFF);

            for (LyricsPlayer.Active a : PLAYER.active) {
                long age = now - a.spawn;
                float f = Math.min(1f, Math.min(age / 500f, (life - age) / 1500f));
                int alpha = Math.max(5, (int) (255 * Math.max(0f, f)));
                Vec3d p = a.pos(mc.player, ctx.tickDelta(), now);
                float dist = a.around ? 4f : CFG.distance;
                float s = 0.008f * dist * CFG.scale;

                m.push();
                m.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
                m.multiply(ctx.camera().getRotation());
                m.scale(-s, -s, s);
                Matrix4f mat = m.peek().getPositionMatrix();
                float w = font.getWidth(a.text);
                font.draw(a.text, -w / 2f, 0, (alpha << 24) | rgb, false, mat, vc,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
                m.pop();
            }
            vc.draw();
        });
    }
}
