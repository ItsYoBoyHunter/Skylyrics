Sky Lyrics (Fabric, Minecraft 1.20.1)
1. Put the built jar + Fabric API in your mods folder.
2. Put lyrics in <game dir>/skylyrics/lyrics.txt (plain lines, or LRC-style [mm:ss.xx] timestamps).
3. In game: /lyrics start | stop | reload | folder | mode sky|around | sky <preset|hex> | color <hex> | scale | distance | interval
Menu: press K (rebindable in Controls) or run /lyrics menu.
